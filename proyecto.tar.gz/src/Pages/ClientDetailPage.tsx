import React from "react";

const ClientDetailPage: React.FC = () => {
  return (
    <div className="w-full h-full shadow shadow-primary bg-foreground-800 rounded-md flex flex-col justify-evenly items-center">
      ClientDetailPage
    </div>
  );
};

export default ClientDetailPage;
